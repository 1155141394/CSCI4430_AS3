#include <stdlib.h>
#include <chrono>
#include <iostream>
#include "PacketHeader.h"
using namespace std::chrono;
using namespace std;

#define WTP_DATA_SIZE 1456

class Timer{
private:
    high_resolution_clock::time_point start;

public:
    void startTimer(){
        start = high_resolution_clock::now();
    }

    double getTime(){
        return duration<double>(high_resolution_clock::now() - start).count();
    }
};

class logger{
    ofstream file;
public:
    logger(char* filename){
        file.open(filename, ios::app);
    }

    void record(PacketHeader header){
        switch (header.type) {
            case 0:
                file << "0 " << header.seqNum << " " << 0 << " " << 0 << endl;
                break;

            case 1:
                file << "1 " << header.seqNum << " " << 0 << " " << 0 << endl;
                break;

            case 2:
                file << "2 " << header.seqNum << " " << header.length << " " << header.checksum << endl;
                break;

            case 3:
                file << "3 " << header.seqNum << " " << 0 << " " << 0 << endl;
                break;
        }
        file.flush();
    }

    void close(){
        file.close();
    }
};

/* combine header and data together */
typedef struct {
    PacketHeader header;
    char data[WTP_DATA_SIZE];
} WrappedBuffer;

PacketHeader decode_header(char *buffer) {
    PacketHeader res;
    memcpy(&(res.type), buffer, 4);
    memcpy(&(res.seqNum) ,buffer + 4, 4);
    memcpy(&(res.length), buffer + 8, 4);
    memcpy(&(res.checksum), buffer + 12, 4);
    return res;
}

void put_header(char *buffer, PacketHeader header) {
    memcpy(buffer, &(header.type), 4);
    memcpy(buffer + 4, &(header.seqNum), 4);
    memcpy(buffer + 8, &(header.length), 4);
    memcpy(buffer + 12, &(header.checksum), 4);
}

void print(const char* name, PacketHeader header){
    cout << name << " " << ends;
    switch (header.type) {
        case 0:
            cout << "START " << header.seqNum << endl;
            break;

        case 1:
            cout << "FIN " << header.seqNum << endl;
            break;

        case 2:
            cout << "DATA " << header.seqNum << " LEN " << header.length << endl;
            break;

        case 3:
            cout << "ACK " << header.seqNum << endl;
            break;
    }
}
